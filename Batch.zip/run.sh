$ java -jar BatchEmail-0.1.0.jar -Djava.library.path=\lib\
